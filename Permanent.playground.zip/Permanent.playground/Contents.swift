import UIKit


//Dispatch Source Timer
var retryCount = 0
let timer = DispatchSource.makeTimerSource()

timer.setEventHandler {
    incrCounter()
}

timer.schedule(deadline: .now(), repeating: .milliseconds(15))

func incrCounter() {
    retryCount += 1
    print(retryCount)
    
    if retryCount > 3 {
        timer.cancel()
    }
}

func doSomething() {
    timer.resume()
}
  

doSomething()
