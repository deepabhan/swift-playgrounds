import UIKit


//enums
enum First {
    case one
    case two
}

enum Second {
    case one
    case two
}

if First.one == First.two {
    print("Same")
}
else {
    print("Different")
}

//guard =========
func some() {
    guard false else {
        print("yes")
        return
    }
    
    print("no")
}

some()
//=========

let numArray = [1, 2, 3]

//range
let currentIndex = 3
let start = numArray[..<currentIndex].reduce(0) {
    $0 + $1
}

let end = numArray[...currentIndex].reduce(0) {
    $0 + $1
}

//reduce
let reduction = numArray.reduce(0) {
    $0 + $1
}

let ccc: [String: Int] = ["xx": 1, "xy": 2]

let t = ccc["xz"]


// sort an array of tuples
typealias SomeTuple = (x:Int, y:Int)
var someArray = [SomeTuple]()

let x1 = SomeTuple(x: 1, y:2)
let x2 = SomeTuple(x: 2, y:2)
let x3 = SomeTuple(x: 3, y:2)

someArray.append(x1)
someArray.append(x2)
someArray.append(x3)
let newArray = someArray.sorted{ $0.x < $1.x }
print(newArray)

// array subtraction/intersection
let myIntArray = [1, 2, 3, 4, 5, 6]
let myIntSet = Set(myIntArray)

let anotherIntArray = [4, 5, 6]
let anotherIntSet = Set(anotherIntArray)

let subtractionResult = myIntSet.subtracting(anotherIntSet).sorted()
let intersectionResulr = myIntSet.intersection(anotherIntSet).sorted()


// array map
let arrayA = [1,2,3,4,5]

let mapOfArray = arrayA.map {
    $0 + 1
}

print(mapOfArray)

// array of tuples map then joined then compact map
// sort an array of tuples
typealias SomeTuple1 = (x:Int, y:Int)
var someArray1 = [SomeTuple1]()

let x11 = SomeTuple1(x: 1, y:2)
let x22 = SomeTuple1(x: 2, y:2)
let x33 = SomeTuple1(x: 3, y:2)

someArray1.append(x11)
someArray1.append(x22)
someArray1.append(x33)

let newArray1 = someArray1.map {
    return($0.x, $0.y)
}

let newArray2 = someArray1.map {
    return([$0.x, $0.y])
}.joined().compactMap { $0 }

print(newArray1)
print(newArray2)

let x = [1, 2, 3, 4, 5]

x.map {
    $0 + 0
}
