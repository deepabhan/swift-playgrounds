import UIKit
import SwiftUI
import PlaygroundSupport

// Make a swiftUI view

struct ContentView: View {
    var body: some View {
        Text("SwiftUI in a playground")
            .onAppear {
                try getEarthquakeData()
            }
    }
    
    func getEarthquakeData() async throws {
        guard let endpoint = URL(string: "https://earthquake.usgs.gov/feed/v0.1/summary/all-month.csv") else {
            return
        }
        
        for try await event in endpoint.lines.dropFirst() {
            let values = event.split(separator: ",")
            let time = values[0]
            let latitude = values[1]
            let longitude = values[2]
            let magnitude = values[4]
            
            print("\(time), \(latitude), \(longitude), \(magnitude)")
        }
    }
}

//Make a UIHostingController
let viewController = UIHostingController(rootView: ContentView())

//Assign it to playgrounds live view
PlaygroundPage.current.liveView = viewController
