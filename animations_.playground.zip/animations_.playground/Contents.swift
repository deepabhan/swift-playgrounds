//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    let progressRingLayer = CAShapeLayer()

    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let view2 = UIView(frame: CGRect(x: 100, y: 100, width: 185, height: 185))
        view.addSubview(view2)
        
        let width = view2.frame.width
        let height = view2.frame.height
        let halfWidth = width * 0.5
        let halfHeight = height * 0.5
        
        let ringPath = UIBezierPath(
            arcCenter: CGPoint(x: halfWidth, y: halfHeight),
            radius: (width - 1.5) / 2,
            startAngle: -0.5 * CGFloat.pi,
            endAngle: 1.5 * CGFloat.pi,
            clockwise: true
        )
        progressRingLayer.path = ringPath.cgPath
        progressRingLayer.frame = view.frame
        progressRingLayer.fillColor = UIColor.clear.cgColor
        progressRingLayer.strokeColor = UIColor.red.cgColor
        progressRingLayer.lineWidth = 10.0
        progressRingLayer.strokeEnd = 1.0

        view2.layer.addSublayer(progressRingLayer)
        animateOpacity()
    }
    
    func animateOpacity() {
        let animation1 = CABasicAnimation(keyPath: "opacity")
        animation1.fromValue = 0.2
        animation1.toValue = 1.0
        animation1.duration = 5.0
        animation1.isRemovedOnCompletion = false
        animation1.autoreverses = true
        animation1.timingFunction = CAMediaTimingFunction(name: .linear)
        animation1.repeatCount = .greatestFiniteMagnitude
        
        progressRingLayer.add(animation1, forKey: "opacity")
    }
    
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
