import UIKit

let hues = ["Heliotrop": 296, "coral": 16, "Aquamarine": 156]
if let leastHue  = hues.min(by: { a, b in
    print("a: \(a)")
    print("b: \(b)")
    return a.value < b.value
})
{
    print(leastHue)
}
