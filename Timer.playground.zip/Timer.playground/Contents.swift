import Foundation

let timer = DispatchSource.makeTimerSource()
timer.schedule(deadline: .now() + 1.0, repeating: 1.0)

timer.setEventHandler {
    print("Deepa")
    print(Date().description)
}

timer.resume()
