import UIKit


//smallest
let blueView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
blueView.backgroundColor = UIColor.blue

// medium
let greenView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
greenView.backgroundColor = UIColor.green

//biggest
let redView = UIView(frame: CGRect(x: 30, y: 30, width: 300, height: 300))
redView.backgroundColor = UIColor.red

//main
let grayView = UIView(frame: CGRect(x: 0, y: 0, width: 500, height: 500))
grayView.backgroundColor = UIColor.gray

greenView.addSubview(blueView)
redView.addSubview(greenView)
grayView.addSubview(redView)

//One way of taking a screenshot
if let view = redView.snapshotView(afterScreenUpdates: true) {
    let snapshot = view
    print(snapshot.frame)
}

// another way to take a screen shot
let image = greenView.snapshot(of: greenView.frame)

extension UIView {
    func snapshot(of rect: CGRect? = nil, afterScreenUpdates: Bool = true) -> UIImage {
        return UIGraphicsImageRenderer(bounds: rect ?? bounds).image { _ in
            drawHierarchy(in: bounds, afterScreenUpdates: afterScreenUpdates)
        }
    }
}
